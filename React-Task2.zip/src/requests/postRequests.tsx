import data from "./fakeDate";

export default data.init;
